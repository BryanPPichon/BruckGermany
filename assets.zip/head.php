<style data-merge-styles="true"></style><style data-merge-styles="true"></style><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="keywords" content="Autopartes, Refacciones, Frenos, Suspensión, Motor, Eléctrico, Colisión, Volkswagen, Nissan, Chevrolet, Lanzamientos, Productos, Calidad, Respaldo, Servicio, Durabilidad, Innovación, Excelencia, Confianza, bruck, bruck germany, catalogo bruck, catalogo digital, bruck catalogo, euroespana, euro españa, euroespaña, euro espada, catalogo euro, catalogo euro España, clutch, refacciones vw, refacciones Nissan, refacciones Chevrolet, refacciones ford, bruck germany, motoventilador, rotula, balatas, discos, carter, cremallera, caja direccion, soporte motor, inyector, inyectores, soporte motor, amortiguador cajuela, alternador, bobina, bobinas, marcha, volkswagen, refacciones jetta, refacciones golf, refacciones vento, refacciones versa, refacciones tsuru, refacciones polo, refacciones chevy, refacciones pointer, refacciones tiguan">
<meta name="description" content="Brück Germany nació hace más de 22 años con un objetivo: ser los mejores en la Industria de autopartes y repuestos en el país.">
<title>Inicio - Brück Germany</title>
<link rel="icon" type="image/png" href="assets/favicon/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="assets/favicon/favicon57x57.png">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/favicon/favicon57x57.png">
<link rel="apple-touch-icon" sizes="72x72" href="assets/favicon/favicon72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="assets/favicon/favicon114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="assets/favicon/favicon120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="assets/favicon/favicon114x114.png">
<link rel="apple-touch-icon" sizes="152x152" href="assets/favicon/favicon152x152.png">
<!-- Twitter meta -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="bruckgermany">
<meta name="twitter:creator" content="bruckgermany">
<meta property="og:url" content="https://bruck.com.mx">
<meta property="og:title" content="Bienvenido a Brück Germany">
<meta property="og:description" content="Brück Germany nació hace más de 22 años con un objetivo: ser los mejores en la Industria de autopartes y repuestos en el país.">
<meta property="og:image" content="https://vmasideas.agency/bruck/img/tw.jpg">
<!-- Facebook meta -->
<meta property="og:url" content="https://bruck.com.mx">
<meta property="og:type" content="article">
<meta property="og:title" content="Bienvenido a Brück Germany">
<meta property="og:description" content="Brück Germany nació hace más de 22 años con un objetivo: ser los mejores en la Industria de autopartes y repuestos en el país.">
<meta property="og:image" content="https://vmasideas.agency/bruck/img/fb.jpg">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.min.css">