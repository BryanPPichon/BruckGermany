<div class="container-loader">
    <div class="loader">
        <div class="container-bar">
            <div id="bar"></div>
            <div id="percent">0%</div>
        </div>
        <div class="content-loader-text">
            <a href="#">
                <h4>activar sonido</h4>
            </a>
            <h1>Cargando</h1>
            <h3 id="ldx">X: </h3>
        </div>
    </div>
</div>