<!DOCTYPE html>
<html lang="en">
<head>
    <?php
        require_once("head.php");
        require_once("tracking.php");
    ?>
</head>
<body>
    <?php
        require_once("header.php");
    ?>
    
    <?php
        require_once("footer.php");
    ?>
</body>
</html>